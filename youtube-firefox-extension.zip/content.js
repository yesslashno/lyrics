(() => {
  function sample() {
    const video=document.querySelector('video.html5-main-video') || document.querySelector('video');
    const videoId=new URL(location.href).searchParams.get('v');
    let playback=null;
    if(location.pathname==='/watch' && /^[\w-]{11}$/.test(videoId || '') && video && Number.isFinite(video.duration) && video.duration>0) {
      const title=(document.querySelector('ytd-watch-metadata h1')?.textContent || document.title.replace(/ - YouTube$/,'')).trim();
      const channel=(document.querySelector('ytd-watch-metadata ytd-channel-name a')?.textContent || '').trim();
      playback={videoId,title:title.slice(0,500),channel:channel.slice(0,300),position:video.currentTime,duration:video.duration,paused:video.paused || video.readyState<3,ad:!!document.querySelector('.ad-showing, .ad-interrupting')};
    }
    browser.runtime.sendMessage({type:'playback',playback}).catch(()=>{});
  }
  for(const event of ['play','playing','waiting','pause','seeked','loadedmetadata','ended'])document.addEventListener(event,sample,true);
  document.addEventListener('yt-navigate-finish',sample);
  setInterval(sample,2000);sample();
})();
