let token='',selectedTab=null,mode='stopped',status='Not paired',queued,working=false,generation=0,order=0;
const frames=new Map();
const ready=browser.storage.local.get('cloudPairingCode').then(value=>{token=value.cloudPairingCode || '';});
const youtube=url=>/^https:\/\/www\.youtube\.com\//.test(url || '');
async function sendQueue(){
 if(working)return;working=true;
 while(queued!==undefined){
  const job=queued;queued=undefined;const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),3000);
  try{const response=await fetch('https://lyrics-youtube.hunkyard-dog.workers.dev/api/playback',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+job.token},body:JSON.stringify(job.playback),signal:controller.signal});
   if(job.generation===generation)status=response.ok?(mode==='stopped'?'Stopped':job.playback?.ad?'YouTube ad — lyrics paused':job.playback?mode==='auto'?'Automatically following YouTube':'Following this tab':'Waiting for a video'):response.status===401?'Pairing expired. Copy a new code from the companion.':'The companion rejected the update.';
  }catch{if(job.generation===generation)status='Can’t reach the companion. Check your internet connection.';}finally{clearTimeout(timer);}
 }
 working=false;
}
function enqueue(playback){queued={token,playback,generation};sendQueue();}
function pickAuto(senderId){
 const previous=selectedTab,now=Date.now(),current=frames.get(selectedTab);
 const eligible=frame=>frame && frame.playback && !frame.playback.paused && !frame.muted && now-frame.at<7000;
 // Keep the current playing tab, including through its advertisements. Other tabs cannot steal it.
 if(!eligible(current)){
  const candidates=[...frames.entries()].filter(([,frame])=>eligible(frame) && !frame.playback.ad).sort((a,b)=>b[1].started-a[1].started);
  if(candidates.length)selectedTab=candidates[0][0];
  else if(!current?.playback)selectedTab=null;
 }
 if(selectedTab!==null && (previous!==selectedTab || selectedTab===senderId))enqueue(frames.get(selectedTab).playback);
 else if(previous!==null && selectedTab===null)enqueue(null);
}
browser.runtime.onMessage.addListener(async(message,sender)=>{
 await ready;
 if(message.type==='playback'){
  if(!sender.tab || !youtube(sender.tab.url))return;
  const version=generation,id=sender.tab.id;
  let muted=message.muted===true;
  if(mode==='auto'){try{const tab=await browser.tabs.get(id);if(!youtube(tab.url))return;muted=muted || !!tab.mutedInfo?.muted;}catch{return;}if(version!==generation)return;}
  const previous=frames.get(id),playing=message.playback && !message.playback.paused;
  frames.set(id,{playback:message.playback,muted,videoMuted:message.muted===true,at:Date.now(),started:playing && (!previous?.playback || previous.playback.paused)?++order:previous?.started || 0});
  if(!token)return;
  if(mode==='auto')pickAuto(id);
  else if(mode==='tab' && id===selectedTab)enqueue(message.playback);
  return;
 }
 if(sender.tab || !sender.url?.startsWith(browser.runtime.getURL('')))return;
 if(message.type==='status')return {status,paired:!!token,following:mode!=='stopped',mode};
 if(message.type==='start' || message.type==='auto'){
  if(!/^[a-f0-9]{48}$/.test(message.code || ''))return {error:'Paste the 48-character pairing code shown by the companion’s YouTube page.'};
  let tab;if(message.type==='start'){[tab]=await browser.tabs.query({active:true,currentWindow:true});if(!tab || !/^https:\/\/www\.youtube\.com\/watch\?/.test(tab.url || ''))return {error:'Open a YouTube music video in this tab first.'};}
  generation++;token=message.code;await browser.storage.local.set({cloudPairingCode:token});mode=message.type==='auto'?'auto':'tab';selectedTab=tab?.id ?? null;
  status=mode==='auto'?'Automatic mode · play a YouTube video':'Waiting for the next playback update…';
  if(mode==='auto')pickAuto(null);
  return {status,mode};
 }
 if(message.type==='stop'){generation++;mode='stopped';selectedTab=null;if(token)enqueue(null);return {status:'Stopped',mode};}
});
browser.tabs.onRemoved.addListener(id=>{frames.delete(id);if(id===selectedTab){selectedTab=null;if(mode==='auto')pickAuto(null);if(selectedTab===null && token && mode!=='stopped')enqueue(null);}});
browser.tabs.onUpdated.addListener((id,changes)=>{if(changes.url && !youtube(changes.url)){frames.delete(id);if(id===selectedTab){selectedTab=null;if(mode==='auto')pickAuto(null);if(selectedTab===null && token && mode!=='stopped')enqueue(null);}return;}const frame=frames.get(id);if(mode==='auto' && frame && changes.mutedInfo){frame.muted=frame.videoMuted || !!changes.mutedInfo.muted;pickAuto(id);}});
