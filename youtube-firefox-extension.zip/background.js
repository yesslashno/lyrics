let token='',selectedTab=null,status='Not paired',queued,working=false;
const ready=browser.storage.local.get('cloudPairingCode').then(value=>{token=value.cloudPairingCode || '';});
async function sendQueue(){
  if(working)return;working=true;
  while(queued!==undefined){
    const job=queued;queued=undefined;const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),3000);
    try{
      const response=await fetch('https://lyrics-youtube.hunkyard-dog.workers.dev/api/playback',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+job.token},body:JSON.stringify(job.playback),signal:controller.signal});
      status=response.ok?(selectedTab===null?'Stopped':job.playback?.ad?'YouTube ad — lyrics paused':job.playback?'Sending this YouTube tab':'Waiting for a video'):response.status===401?'Pairing code expired. Copy a new code from the companion’s YouTube page.':'The companion rejected the update.';
    }catch{status='Can’t reach the companion. Check your internet connection.';}finally{clearTimeout(timer);}
  }
  working=false;
}
function enqueue(playback){queued={token,playback};sendQueue();}
browser.runtime.onMessage.addListener(async(message,sender)=>{
  await ready;
  if(message.type==='playback'){
    if(sender.tab?.id!==selectedTab || !/^https:\/\/www\.youtube\.com\//.test(sender.tab?.url || '') || !token)return;
    enqueue(message.playback);return;
  }
  // Configuration messages only come from this extension's own popup.
  if(sender.tab || !sender.url?.startsWith(browser.runtime.getURL('')))return;
  if(message.type==='status')return {status,paired:!!token,following:selectedTab!==null};
  if(message.type==='start'){
    if(!/^[a-f0-9]{48}$/.test(message.code || ''))return {error:'Paste the 48-character pairing code shown by the companion’s YouTube page.'};
    const [tab]=await browser.tabs.query({active:true,currentWindow:true});
    if(!tab || !/^https:\/\/www\.youtube\.com\/watch\?/.test(tab.url || ''))return {error:'Open a YouTube music video in this tab first.'};
    token=message.code;await browser.storage.local.set({cloudPairingCode:token});selectedTab=tab.id;status='Waiting for the next playback update…';return {status};
  }
  if(message.type==='stop'){selectedTab=null;if(token)enqueue(null);return {status:'Stopped'};}
});
browser.tabs.onRemoved.addListener(id=>{if(id===selectedTab){selectedTab=null;if(token)enqueue(null);}});
