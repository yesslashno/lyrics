const status=document.getElementById('status');
browser.storage.local.get('cloudPairingCode').then(value=>{document.getElementById('code').value=value.cloudPairingCode || '';});
browser.runtime.sendMessage({type:'status'}).then(value=>{status.textContent=value.status;});
document.getElementById('start').onclick=async()=>{const result=await browser.runtime.sendMessage({type:'start',code:document.getElementById('code').value.trim()});status.textContent=result.error || result.status;};
document.getElementById('stop').onclick=async()=>{const result=await browser.runtime.sendMessage({type:'stop'});status.textContent=result.status;};

document.getElementById('auto').onclick=async()=>{const result=await browser.runtime.sendMessage({type:'auto',code:document.getElementById('code').value.trim()});status.textContent=result.error || result.status;};
